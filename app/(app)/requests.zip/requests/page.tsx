// app/(app)/requests/page.tsx
import { auth } from '@/auth.config';
import Link from 'next/link';
import './requests.css';
import RequestsList from './RequestsList';

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function Page(props: { searchParams: SearchParams }) {
  const sp = await props.searchParams;
  const created = sp?.created === '1';

  const session = await auth();
  const meId = session?.user?.id ?? null;

  if (!meId) {
    return (
      <div className="req-page">
        <h1>Заявки</h1>
        <p>Нужна авторизация.</p>
      </div>
    );
  }

  return (
    <div className="req-page">
      <div className="grid">
        <div className="left">
          <div className="card">
            <h2>Новая заявка</h2>
            <Link href="/requests/new" className="btn-primary">Открыть форму</Link>
          </div>
        </div>
        <div className="right">
          <div className="req-list-head">
            <h1>Заявки</h1>
            {created && <div className="alert-success">Заявка создана</div>}
          </div>
          <RequestsList />
        </div>
      </div>
    </div>
  );
}
