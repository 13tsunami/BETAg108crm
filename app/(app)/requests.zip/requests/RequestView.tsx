type UserLite = { id: string; name: string | null };

type Msg = {
  id: string;
  body: string;
  createdAt: Date;
  author: UserLite | null;
};

type Request = {
  id: string;
  target: string;
  globalNumber: number;
  targetNumber: number | null; // в Prisma это Int?
  status: 'new' | 'in_progress' | 'done' | 'rejected';
  title: string;
  body: string | null;
  createdAt: Date;
  closedAt: Date | null;
  rejectedReason: string | null;
  author: UserLite | null;
  processedBy: UserLite | null;
  messages: Msg[];
};

function fmtRuDateTime(d?: Date | string | null): string {
  if (!d) return '';
  const dt = typeof d === 'string' ? new Date(d) : d;
  const f = new Intl.DateTimeFormat('ru-RU', {
    timeZone: 'Asia/Yekaterinburg',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(dt);
  return f.replace('.', '');
}

export default function RequestView({ request }: { request: Request }) {
  return (
    <div className="card">
      <div className="req-card-top">
        <span className="req-tag">{request.target}</span>
        <span className={`req-status s-${request.status}`}>{request.status}</span>
      </div>

      <h2 className="req-title">{request.title}</h2>
      <div className="req-meta">
        <span>
          № {request.globalNumber}
          {typeof request.targetNumber === 'number' ? ` / ${request.targetNumber}` : ''}
        </span>
        <span>Автор: {request.author?.name ?? '—'}</span>
        <span>Обработчик: {request.processedBy?.name ?? '—'}</span>
        <span>Создано: {fmtRuDateTime(request.createdAt)}</span>
        {request.closedAt && <span>Закрыто: {fmtRuDateTime(request.closedAt)}</span>}
        {request.status === 'rejected' && request.rejectedReason && (
          <span>Причина отклонения: {request.rejectedReason}</span>
        )}
      </div>

      {request.body && <p className="req-body">{request.body}</p>}

      <div className="req-messages">
        {request.messages.map((m) => (
          <div key={m.id} className="req-msg">
            <div className="req-msg-head">
              <b>{m.author?.name ?? '—'}</b>
              <span className="muted">{fmtRuDateTime(m.createdAt)}</span>
            </div>
            <div className="req-msg-body">{m.body}</div>
          </div>
        ))}
        {request.messages.length === 0 && <div className="muted">Пока нет ответов</div>}
      </div>
    </div>
  );
}
