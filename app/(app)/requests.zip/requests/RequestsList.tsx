// app/(app)/requests/RequestsList.tsx
import Link from 'next/link';
import { auth } from '@/auth.config';
import { prisma } from '@/lib/prisma';
import { normalizeRole, isRole } from '@/lib/roles';
import { ROLE_LABELS } from '@/lib/roleLabels';

const STATUS_LABELS: Record<'new' | 'in_progress' | 'done' | 'rejected', string> = {
  new: 'новая',
  in_progress: 'в работе',
  done: 'закрыта',
  rejected: 'отклонена',
};

function fmtRuDate(d?: Date | string | null): string {
  if (!d) return '';
  const dt = typeof d === 'string' ? new Date(d) : d;
  const f = new Intl.DateTimeFormat('ru-RU', {
    timeZone: 'Asia/Yekaterinburg',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }).format(dt);
  return f.replace('.', '');
}

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function RequestsList() {
  const session = await auth();
  const meId = session?.user?.id ?? null;
  const role = normalizeRole(session?.user?.role);

  if (!meId) {
    return <div className="req-empty">Нужна авторизация.</div>;
  }

  const where =
    role === 'sysadmin' || role === 'deputy_axh'
      ? {}
      : { OR: [{ authorId: meId }, { processedById: meId }] };

  const items = await prisma.request.findMany({
    where,
    orderBy: { lastMessageAt: 'desc' },
    select: {
      id: true,
      target: true,
      status: true,
      title: true,
      globalNumber: true,
      targetNumber: true,
      author: { select: { name: true } },
      processedBy: { select: { name: true } },
      lastMessageAt: true,
    },
    take: 100,
  });

  if (items.length === 0) {
    return <div className="req-empty">Нет заявок</div>;
  }

  return (
    <div className="req-list">
      {items.map((r) => {
        const targetLabel = isRole(r.target) ? ROLE_LABELS[r.target] : r.target;
        const statusLabel = STATUS_LABELS[r.status as keyof typeof STATUS_LABELS] ?? r.status;

        return (
          <Link key={r.id} href={`/requests/${r.id}`} className="req-card">
            <div className="req-row">
              <span className="req-tag">{targetLabel}</span>
              <span className={`req-status s-${r.status}`}>{statusLabel}</span>
            </div>

            <div className="req-title">{r.title}</div>

            <div className="req-meta">
              <span className="req-num">
                <span className="req-gn">№ {r.globalNumber}</span>
                {typeof r.targetNumber === 'number' && <span className="req-tn">/ {r.targetNumber}</span>}
              </span>
              <span>Автор: {r.author?.name ?? '—'}</span>
              <span>Обработчик: {r.processedBy?.name ?? '—'}</span>
              <span>{fmtRuDate(r.lastMessageAt)}</span>
            </div>
          </Link>
        );
      })}
    </div>
  );
}
