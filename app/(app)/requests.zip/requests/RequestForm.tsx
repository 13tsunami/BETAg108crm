'use client';

import { useFormStatus } from 'react-dom';
import { createRequestAction } from './actions';
import { ROLE_LABELS, VISIBLE_ROLES } from '@/lib/roleLabels';
import type { Role } from '@/lib/roles';

export default function RequestForm() {
  return (
    <form action={createRequestAction} className="req-form">
      <div className="field">
        <label htmlFor="target">Адресат</label>
        <select id="target" name="target" required defaultValue="" className="select">
          <option value="" disabled>Выберите адресата</option>
          {VISIBLE_ROLES.map((r: Role) => (
            <option key={r} value={r}>{ROLE_LABELS[r]}</option>
          ))}
        </select>
      </div>

      <div className="field">
        <label htmlFor="title">Заголовок</label>
        <input id="title" name="title" required maxLength={256} placeholder="Коротко о проблеме" className="input" />
      </div>

      <div className="field">
        <label htmlFor="room">Кабинет</label>
        <input id="room" name="room" maxLength={64} placeholder="Например: 208" className="input" />
      </div>

      <div className="field">
        <label htmlFor="body">Описание</label>
        <textarea id="body" name="body" className="textarea" placeholder="Подробности (по возможности — инвентарный номер, контакты, удобное время)"></textarea>
      </div>

      <SubmitBtn>Сохранить</SubmitBtn>
    </form>
  );
}

function SubmitBtn({ children }: { children: React.ReactNode }) {
  const { pending } = useFormStatus();
  return (
    <button type="submit" className="btn-primary" disabled={pending}>
      {pending ? 'Сохранение…' : children}
    </button>
  );
}
