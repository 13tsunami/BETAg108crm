import { auth } from '@/auth.config';
import { normalizeRole, canCreateRequests } from '@/lib/roles';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import RequestForm from '../RequestForm';
import '../requests.css';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function Page() {
  const session = await auth();
  const meId = session?.user?.id ?? null;
  const role = normalizeRole(session?.user?.role);

  if (!meId) redirect('/');

  if (!canCreateRequests(role)) {
    return (
      <div className="req-page">
        <div className="card">
          <h1>Новая заявка</h1>
          <p className="muted">Создание заявок недоступно для вашей роли.</p>
          <p><Link href="/requests" className="btn-outline">К списку заявок</Link></p>
        </div>
      </div>
    );
  }

  return (
    <div className="req-page">
      <div className="grid">
        <div className="left">
          <div className="card">
            <h1>Новая заявка</h1>
            <RequestForm />
          </div>
        </div>
        <div className="right">
          <div className="card">
            <h2>Подсказки</h2>
            <p className="muted">Укажите адресата, краткий заголовок и описание. После сохранения вы сможете дополнять переписку ответами.</p>
            <p><Link href="/requests" className="btn-outline">К списку заявок</Link></p>
          </div>
        </div>
      </div>
    </div>
  );
}
