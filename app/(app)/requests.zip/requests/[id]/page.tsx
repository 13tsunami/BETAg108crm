import { auth } from '@/auth.config';
import { prisma } from '@/lib/prisma';
import { normalizeRole } from '@/lib/roles';
import { redirect, notFound } from 'next/navigation';
import RequestView from '../RequestView';
import ReplyForm from '../ReplyForm';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

type Params = Promise<{ id: string }>;

function isUuid(v: string): boolean {
  // простая проверка UUID v4/v1: 8-4-4-4-12 шестнадцатеричных символов
  return /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$/.test(v);
}

function canSeeRequest(opts: {
  meId: string;
  role: ReturnType<typeof normalizeRole>;
  authorId: string;
  processedById: string | null;
}) {
  const { meId, role, authorId, processedById } = opts;
  if (role === 'sysadmin' || role === 'deputy_axh') return true;
  if (authorId === meId) return true;
  if (processedById && processedById === meId) return true;
  return false;
}

function canRenderReplyPane(role: ReturnType<typeof normalizeRole>) {
  return role === 'sysadmin' || role === 'deputy_axh';
}

export default async function Page(props: { params: Params }) {
  const { id } = await props.params;
  const session = await auth();
  const meId = session?.user?.id;
  const role = normalizeRole(session?.user?.role);

  if (!meId) redirect('/');

  // если пользователь случайно попал на /requests/new, отправляем на форму
  if (id === 'new') redirect('/requests/new');

  // защита Prisma от не-UUID
  if (!isUuid(id)) redirect('/requests');

  const req = await prisma.request.findUnique({
    where: { id },
    include: {
      author: { select: { id: true, name: true } },
      processedBy: { select: { id: true, name: true } },
      messages: {
        orderBy: { createdAt: 'asc' },
        include: { author: { select: { id: true, name: true } } },
      },
    },
  });

  if (!req) notFound();

  if (
    !canSeeRequest({
      meId,
      role,
      authorId: req.authorId,
      processedById: req.processedById,
    })
  ) {
    redirect('/requests');
  }

  const allowReplyUI = canRenderReplyPane(role);

  return (
    <div className="req-page">
      <div className="grid">
        <div className="left">
          {allowReplyUI ? (
            <div className="card sticky">
              <h2>Ответ по заявке</h2>
              <ReplyForm requestId={req.id} />
            </div>
          ) : (
            <div className="card sticky">
              <h2>Ответ недоступен</h2>
              <p className="muted">Панель ответа доступна только для системного администратора и заместителя по АХЧ.</p>
            </div>
          )}
        </div>
        <div className="right">
          <RequestView request={req} />
        </div>
      </div>
    </div>
  );
}
