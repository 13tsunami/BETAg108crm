'use client';

import { useFormStatus } from 'react-dom';
import {
  replyRequestAction,
  takeInWorkAction,
  closeRequestAction,
  rejectRequestAction,
} from './actions';

export default function ReplyForm(props: { requestId: string }) {
  const { requestId } = props;

  return (
    <div className="reply-form">
      <form action={replyRequestAction}>
        <input type="hidden" name="requestId" value={requestId} />
        <textarea name="body" required className="textarea" placeholder="Текст ответа..." />
        <div style={{ display:'flex', justifyContent:'flex-start' }}>
          <SubmitBtn className="btn btn-primary">Отправить</SubmitBtn>
        </div>
      </form>

      <div className="reply-actions">
        <form action={takeInWorkAction}>
          <input type="hidden" name="requestId" value={requestId} />
          <SubmitBtn className="btn btn-outline">Взять в работу</SubmitBtn>
        </form>

        <form action={closeRequestAction}>
          <input type="hidden" name="requestId" value={requestId} />
          <SubmitBtn className="btn btn-success">Закрыть как выполнено</SubmitBtn>
        </form>

        <form action={rejectRequestAction} style={{ display:'flex', gap:8 }}>
          <input type="hidden" name="requestId" value={requestId} />
          <input name="reason" className="input reason" placeholder="Причина отклонения" required />
          <SubmitBtn className="btn btn-danger">Отклонить</SubmitBtn>
        </form>
      </div>
    </div>
  );
}

function SubmitBtn(props: { children: React.ReactNode; className?: string }) {
  const { pending } = useFormStatus();
  const cls = props.className ?? 'btn btn-primary';
  return (
    <button type="submit" disabled={pending} className={cls}>
      {pending ? 'Сохранение…' : props.children}
    </button>
  );
}
