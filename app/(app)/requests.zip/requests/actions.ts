// app/(app)/requests/actions.ts
'use server';

import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { auth } from '@/auth.config';
import { prisma } from '@/lib/prisma';
import { normalizeRole, canCreateRequests, canProcessRequests } from '@/lib/roles';

function asNonEmpty(form: FormData, name: string, label: string, max = 1000): string {
  const v = String(form.get(name) ?? '').trim();
  if (!v) throw new Error(`Поле "${label}" обязательно`);
  if (v.length > max) throw new Error(`Поле "${label}" слишком длинное`);
  return v;
}
function asOptional(form: FormData, name: string, max = 2000): string | null {
  const v = String(form.get(name) ?? '').trim();
  if (!v) return null;
  if (v.length > max) throw new Error(`Поле "${name}" слишком длинное`);
  return v;
}

async function requireMe() {
  const session = await auth();
  const meId = session?.user?.id ?? null;
  const role = normalizeRole(session?.user?.role);
  if (!meId) throw new Error('Нужна авторизация');
  return { meId, role };
}

/** Создать заявку */
export async function createRequestAction(formData: FormData): Promise<void> {
  const { meId, role } = await requireMe();
  if (!canCreateRequests(role)) throw new Error('Недостаточно прав для создания заявки');

  const target = asNonEmpty(formData, 'target', 'Адресат', 64);
  const title = asNonEmpty(formData, 'title', 'Заголовок', 256);
  const body = asOptional(formData, 'body', 4000);
  const room = asOptional(formData, 'room', 64);

  const finalBody = room ? `Кабинет: ${room}\n\n${body ?? ''}`.trimEnd() : (body ?? '');
  const now = new Date();

  await prisma.$transaction(async (tx) => {
    const cnt = await tx.requestCounter.upsert({
      where: { target },
      update: { lastNumber: { increment: 1 } },
      create: { target, lastNumber: 1 },
      select: { lastNumber: true },
    });

    await tx.request.create({
      data: {
        authorId: meId,
        target,
        status: 'new',
        title,
        body: finalBody,
        lastMessageAt: now,
        targetNumber: cnt.lastNumber,
      },
    });
  });

  revalidatePath('/requests');
  redirect('/requests?created=1');
}

/** Ответить в заявке */
export async function replyRequestAction(formData: FormData): Promise<void> {
  const { meId, role } = await requireMe();
  const requestId = asNonEmpty(formData, 'requestId', 'ID заявки');
  const body = asNonEmpty(formData, 'body', 'Текст', 4000);

  const req = await prisma.request.findUnique({
    where: { id: requestId },
    select: { id: true, authorId: true, processedById: true },
  });
  if (!req) throw new Error('Заявка не найдена');

  const isAuthorOrAssignee = req.authorId === meId || (!!req.processedById && req.processedById === meId);
  const isProcessor = canProcessRequests(role);

  if (!isAuthorOrAssignee && !isProcessor) {
    throw new Error('Нет доступа к этой заявке');
  }

  await prisma.$transaction(async (tx) => {
    await tx.requestMessage.create({ data: { requestId, authorId: meId, body } });
    await tx.request.update({ where: { id: requestId }, data: { lastMessageAt: new Date() } });
  });

  revalidatePath('/requests');
  revalidatePath(`/requests/${requestId}`);
  redirect(`/requests/${requestId}`);
}

/** Взять в работу */
export async function takeInWorkAction(formData: FormData): Promise<void> {
  const { meId, role } = await requireMe();
  if (!canProcessRequests(role)) throw new Error('Недостаточно прав');
  const requestId = asNonEmpty(formData, 'requestId', 'ID заявки');

  await prisma.request.update({
    where: { id: requestId },
    data: { status: 'in_progress', processedById: meId, lastMessageAt: new Date() },
  });

  revalidatePath('/requests');
  revalidatePath(`/requests/${requestId}`);
  redirect(`/requests/${requestId}`);
}

/** Закрыть как выполнено */
export async function closeRequestAction(formData: FormData): Promise<void> {
  const { meId, role } = await requireMe();
  if (!canProcessRequests(role)) throw new Error('Недостаточно прав');
  const requestId = asNonEmpty(formData, 'requestId', 'ID заявки');

  await prisma.request.update({
    where: { id: requestId },
    data: {
      status: 'done',
      closedAt: new Date(),
      processedById: meId,
      lastMessageAt: new Date(),
    },
  });

  revalidatePath('/requests');
  revalidatePath(`/requests/${requestId}`);
  redirect(`/requests/${requestId}`);
}

/** Отклонить с причиной */
export async function rejectRequestAction(formData: FormData): Promise<void> {
  const { meId, role } = await requireMe();
  if (!canProcessRequests(role)) throw new Error('Недостаточно прав');
  const requestId = asNonEmpty(formData, 'requestId', 'ID заявки');
  const reason = asNonEmpty(formData, 'reason', 'Причина', 1000);

  await prisma.request.update({
    where: { id: requestId },
    data: {
      status: 'rejected',
      rejectedReason: reason,
      closedAt: new Date(),
      processedById: meId,
      lastMessageAt: new Date(),
    },
  });

  revalidatePath('/requests');
  revalidatePath(`/requests/${requestId}`);
  redirect(`/requests/${requestId}`);
}
